package com.example.bookinghostelapp.fragment;

import android.database.Cursor;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import com.example.bookinghostelapp.DBHelper;
import com.example.bookinghostelapp.MainViewLayout;
import com.example.bookinghostelapp.R;

import java.util.Objects;


public class ProfileBusinessFragment extends Fragment {

    private EditText usernameEditText;
    EditText txtHostelName,txtHostelAddress,txtRoomAmount,txtPrice,txtStatus,txtDescription;
    // Thêm các EditText tương ứng với các cột khác
    Button submit;
    private DBHelper dbHelper;
    Button btUpdate;

    private MainViewLayout mMainView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_profile_business, container, false);
        txtHostelName=view.findViewById(R.id.txtHostelName_Hostf);
        txtHostelAddress=view.findViewById(R.id.txtHostelAddress_Hostf);
        txtRoomAmount=view.findViewById(R.id.txtRoomAmount_Hostf);
        txtPrice=view.findViewById(R.id.txtPrice_Hostf);
        txtStatus=view.findViewById(R.id.txtStatus_Hostf);
        txtDescription=view.findViewById(R.id.txtDescription_Hostf);
        submit=view.findViewById(R.id.buttonUpdate_Hostf);
        // Ánh xạ các EditText khác tương ứng


        dbHelper = new DBHelper(getActivity());
        dbHelper.open();



        Bundle bundle = getArguments();
        if (bundle != null) {
            String username = bundle.getString("USERNAME", "Default value if key not found");
            Cursor cursor = dbHelper.getHostByUsername(username);
            if (cursor.moveToFirst()) {
                do{
                    txtHostelName.setText(cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.DB_HOST_HOSTEL_NAME)));
                    txtHostelAddress.setText(cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.DB_HOST_HOSTEL_ADDRESS)));
                    txtRoomAmount.setText(cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.DB_HOST_ROOM_AMOUNT)));
                    txtPrice.setText(cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.DB_HOST_PRICE)));
                    txtStatus.setText(cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.DB_HOST_STATUS)));
                    txtDescription.setText(cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.DB_HOST_DESCRIPTION)));

                }
                while (cursor.moveToNext());
                // Lấy giá trị từ Cursor và đặt vào từng EditText


            }
            cursor.close();
            // Đóng Cursor sau khi sử dụng
            submit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dbHelper.open();


                        String hostelName=txtHostelName.getText().toString();
                        String hostelAddress=txtHostelAddress.getText().toString();
                        String roomAmount=txtRoomAmount.getText().toString();
                        String price=txtPrice.getText().toString();
                        String status=txtStatus.getText().toString();
                        String description=txtDescription.getText().toString();

                        dbHelper.updateHost(username,hostelName,hostelAddress,roomAmount,price,status,description);
                        Toast.makeText(requireContext(),"Đã thay đổi thông tin! Xin hãy tải lại trang !!!", Toast.LENGTH_SHORT).show();
                        dbHelper.close();

                }
            });


        }






        return view;

    }

}