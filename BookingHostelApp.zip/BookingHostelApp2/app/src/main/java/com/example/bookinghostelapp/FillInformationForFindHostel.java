package com.example.bookinghostelapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.util.Objects;

public class FillInformationForFindHostel extends AppCompatActivity {
    EditText txtfullname,txtbirthday,txtaddress,txtcity,txtphone,txtemail,txtamounthostel;
    RadioButton rbNam,rbNu;
    private RadioGroup radioGroupGender;
    Button submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fill_information_for_find_hostel);
        DBHelper DB=new DBHelper(this);

        txtfullname=findViewById(R.id.editTextFullName);
        txtbirthday=findViewById(R.id.editTextDOB);
        txtaddress=findViewById(R.id.editTextAddress);
        txtcity=findViewById(R.id.editTextAddressProvince);
        txtphone=findViewById(R.id.editTextPhoneNumber);
        txtemail=findViewById(R.id.editTextEmail);
        rbNam=findViewById(R.id.radioButtonMale);
        rbNu=findViewById(R.id.radioButtonFemale);
        submit=findViewById(R.id.buttonSubmit);
        Intent intent = getIntent();
        String username = intent.getStringExtra("USERNAME");
        String type=intent.getStringExtra("TYPE");


        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DB.open();
                String fullName=txtfullname.getText().toString();
                String birthday=txtbirthday.getText().toString();
                String address=txtaddress.getText().toString();
                String city=txtcity.getText().toString();
                String phone=txtphone.getText().toString();
                String email=txtemail.getText().toString();

                String gender = "";
                if(rbNam.isChecked()==true)
                    gender="Nam";
                else if(rbNu.isChecked()==true)
                    gender="Nữ";


                Boolean checkuser=DB.checkusernameInfor(username);
                if(checkuser==false){
                    Boolean insert= DB.insertInformation(username,fullName,birthday,address,city,email,phone,gender,type);
                    if(insert==true){
                        if(Objects.equals(type, "FindHostel"))
                        {

                            Toast.makeText(FillInformationForFindHostel.this,"Find Hostel",Toast.LENGTH_SHORT).show();
                        }
                        else if(Objects.equals(type, "Business"))
                        {

                               Toast.makeText(FillInformationForFindHostel.this, "Dien Thong Tin Thanh Cong", Toast.LENGTH_SHORT).show();
                                Intent intentHost = new Intent(getApplicationContext(), SubmitHost.class);
                                intentHost.putExtra("USERNAME", username);
                                startActivity(intentHost);

                        }


                }}
            }
        });

    }
}