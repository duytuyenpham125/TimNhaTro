package com.example.bookinghostelapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SetAvartarActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_avartar);
    }
}