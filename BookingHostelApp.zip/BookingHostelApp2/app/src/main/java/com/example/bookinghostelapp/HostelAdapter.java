package com.example.bookinghostelapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;


public class HostelAdapter extends RecyclerView.Adapter<HostelAdapter.HostelViewHolder> {
    private List<Hostel> mHostel;

    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(int position);
    }
    public HostelAdapter(List<Hostel> mHostel,OnItemClickListener listener) {
        this.mHostel = mHostel;
        this.listener=listener;
    }

    @NonNull
    @Override
    public HostelViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_hostel_find,parent,false);
        return new HostelViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HostelViewHolder holder, int position) {

        Hostel hostel =mHostel.get(position);
        if(hostel==null){
            return;
        }
        holder.img.setImageResource(hostel.getImg());
        holder.txtHostelName.setText(hostel.getName());
        holder.txtHostelAddress.setText(hostel.getAddress());
        holder.txtHostelPrice.setText(hostel.getPrice());
    }

    @Override
    public int getItemCount() {
        if(mHostel!=null)
        {
            return mHostel.size();
        }
        return 0;
    }

    public class HostelViewHolder extends RecyclerView.ViewHolder{

        TextView txtHostelName,txtHostelAddress,txtHostelPrice;
        ImageView img;
        public HostelViewHolder(@NonNull View itemView) {
            super(itemView);
            img=itemView.findViewById(R.id.imageHostel);
            txtHostelName= itemView.findViewById(R.id.textViewHostelName);
            txtHostelAddress=itemView.findViewById(R.id.textViewHostelAddress);
            txtHostelPrice=itemView.findViewById(R.id.textViewHostelPrice);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            listener.onItemClick(position);
                        }
                    }
                }
            });
        }
    }
}
