package com.example.bookinghostelapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class ManageActivity extends AppCompatActivity {

    Button btCus,btBus;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage);
        btCus=findViewById(R.id.btt_forFindHostel);
        btBus=findViewById(R.id.btt_forBusiness);

        Intent intentUser= getIntent();
        String username=intentUser.getStringExtra("USERNAME");


        String forCus="FindHostel";
        String forBus="Business";
        btCus.setOnClickListener(view ->{

            Intent intentFill= new Intent(getApplicationContext(), FillInformationForFindHostel.class);
            intentFill.putExtra("TYPE", forCus);
            intentFill.putExtra("USERNAME",username);
            startActivity(intentFill);
        });
        btBus.setOnClickListener(view ->{
            Intent intentFill= new Intent(getApplicationContext(), FillInformationForFindHostel.class);
            intentFill.putExtra("TYPE", forBus);
            intentFill.putExtra("USERNAME",username);
            startActivity(intentFill);
        });
    }
}