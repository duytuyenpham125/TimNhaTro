package com.example.bookinghostelapp.fragment;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.bookinghostelapp.DBHelper;
import com.example.bookinghostelapp.R;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.Objects;

public class MapsFragmentHostView extends Fragment {
    private GoogleMap mMap;
    private FusedLocationProviderClient fusedLocationClient;
    private DBHelper dbHelper;

    private OnMapReadyCallback callback = new OnMapReadyCallback() {

        @SuppressLint("MissingPermission")
        @Override
        public void onMapReady(GoogleMap googleMap) {


            mMap = googleMap;
            mMap.getUiSettings().setMyLocationButtonEnabled(true);
            mMap.setMyLocationEnabled(true);
            mMap.getUiSettings().setZoomControlsEnabled(true);

            Bundle bundle = getArguments();

            if (bundle != null) {
                double latitude = Double.parseDouble(bundle.getString("LATITUDE", "Default value if key not found"));
                double longitude = Double.parseDouble(bundle.getString("LONGITUDE", "Default value if key not found"));
                String name = bundle.getString("NAME","Default value if key not found");

            Toast.makeText(requireContext(), latitude+","+longitude, Toast.LENGTH_SHORT).show();
            LatLng latLng2 = new LatLng(latitude, longitude);

            googleMap.addMarker(new MarkerOptions().position(latLng2).title(name));

            Circle circle2 = mMap.addCircle(new CircleOptions().center(latLng2).radius(50).fillColor(Color.WHITE).strokeColor(Color.BLUE));
        }
        }
    };

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_maps_host_view, container, false);

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {

        super.onViewCreated(view, savedInstanceState);
        SupportMapFragment mapFragment =
                (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.mapview);
        if (mapFragment != null) {
            mapFragment.getMapAsync(callback);
        }
    }

}