package com.example.bookinghostelapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.Objects;

public class SubmitHost extends AppCompatActivity {
    EditText txtHostelName,txtHostelAddress,txtRoomAmount,txtPrice,txtStatus,txtDescription;
    Button submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.submid_forbusiness_activity);
        DBHelper DB = new DBHelper(this);
        txtHostelName = findViewById(R.id.txtHostelName_Host);
        txtHostelAddress = findViewById(R.id.txtHostelAddress_Host);
        txtRoomAmount = findViewById(R.id.txtRoomAmount_Host);
        txtPrice = findViewById(R.id.txtPrice_Host);
        txtStatus = findViewById(R.id.txtStatus_Host);
        txtDescription = findViewById(R.id.txtDescription_Host);
        submit = findViewById(R.id.buttonSubmit_Host);

        Intent intent = getIntent();
        String username = intent.getStringExtra("USERNAME");
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                DB.open();
                String hostel_name = txtHostelName.getText().toString();
                String hostel_address = txtHostelAddress.getText().toString();
                String room_amount = txtRoomAmount.getText().toString();
                String price = txtPrice.getText().toString();
                String status = txtStatus.getText().toString();
                String description = txtDescription.getText().toString();

                Boolean check_user = DB.checkusernameHost(username);
                if (check_user == false) {
                    Boolean insert = DB.insertHost(username, hostel_name, hostel_address, room_amount, price, status, description);
                    if (insert == true) {


                        Toast.makeText(SubmitHost.this, "Dien Thong Tin Thanh Cong", Toast.LENGTH_SHORT).show();
                        Intent intentHost = new Intent(getApplicationContext(), MainViewLayout.class);
                        intentHost.putExtra("USERNAME", username);
                        startActivity(intentHost);

                    }


                }

            }



        });



    }

}