package com.example.bookinghostelapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentManager;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.bookinghostelapp.fragment.HostelViewFragment;
import com.example.bookinghostelapp.fragment.MapsFragment;
import com.example.bookinghostelapp.fragment.ProfileBusinessFragment;
import com.example.bookinghostelapp.fragment.ProfileFragment;
import com.example.bookinghostelapp.fragment.SetAvatarFragment;
import com.google.android.material.navigation.NavigationView;

import java.util.Objects;

public class MainViewLayout extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private TextView nameHeader,emailHeader;
    private  String getUserName="",getType="";
    DBHelper DB=new DBHelper(this);

    ImageView imageView;
    private DrawerLayout drawerLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_view_layout);

        Toolbar toolbar= findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Intent intentUser = getIntent();
        String username = intentUser.getStringExtra("USERNAME");

        drawerLayout=findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle= new ActionBarDrawerToggle(this,drawerLayout,toolbar,R.string.nav_drawer_open,R.string.nav_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();



        NavigationView navigationView=findViewById(R.id.navigation_view);


        navigationView.setNavigationItemSelectedListener(this);
        View headerView = ((NavigationView) findViewById(R.id.navigation_view)).getHeaderView(0);
        DB.open();
        Boolean checkuser=DB.checkusernameInfor(username);
        if(checkuser==true){
            Cursor cursor = DB.getInformationByUsername(username);
            if (cursor.moveToFirst()) {

                nameHeader=headerView.findViewById(R.id.txtName);
                emailHeader=headerView.findViewById(R.id.txtEmail);
                // Lấy giá trị từ Cursor và đặt vào từng EditText
                nameHeader.setText(cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.DB_INFORMATION_FULL_NAME)));
                emailHeader.setText(cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.DB_INFORMATION_PHONE)));

            }
            cursor.close();
        }
        else if(checkuser==false){

            nameHeader=headerView.findViewById(R.id.txtName);
            emailHeader=headerView.findViewById(R.id.txtEmail);
            nameHeader.setText("User");
            emailHeader.setText("");
        }

        imageView=headerView.findViewById(R.id.imageViewAvatar);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getSupportFragmentManager().beginTransaction().replace(R.id.content_frame,new SetAvatarFragment()).commit();
                Toast.makeText(MainViewLayout.this,"Touch Avatar",Toast.LENGTH_SHORT).show();
                drawerLayout.closeDrawer(GravityCompat.START);
            }
        });




    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id= item.getItemId();
        Intent intentUser = getIntent();
        String username = intentUser.getStringExtra("USERNAME");

        if(id==R.id.item_home){
            //getSupportFragmentManager().beginTransaction().replace(R.id.content_frame,new BlankFragment()).commit();
        }

        if(id==R.id.item_manage){
            DB.open();
            Boolean checkuser=DB.checkusernameInfor(username);
            if(checkuser==false){
                Intent intent= new Intent(getApplicationContext(), ManageActivity.class);
                intent.putExtra("USERNAME", username);
                startActivity(intent);
            }
            else if(checkuser==true){

                getUserName=username;
                getSupportFragmentManager().beginTransaction().replace(R.id.content_frame,new ProfileFragment()).commit();


            }
            else{
                Intent intent= new Intent(getApplicationContext(), MainViewLayout.class);
                startActivity(intent);
            }

        }

        else if(id==R.id.item_hostel){


            DB.open();
            Boolean checkuser=DB.checkusernameInfor(username);
            if(checkuser==true){
                Cursor cursor = DB.getInformationByUsername(username);
                if (cursor.moveToFirst()) {
                    String type=cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.DB_ACCOUNT_TYPE));
                    if(Objects.equals(type, "FindHostel")){

                        getSupportFragmentManager().beginTransaction().replace(R.id.content_frame,new HostelViewFragment()).commit();
                    }
                    else if(Objects.equals(type,"Business"))
                    {
                        FragmentManager fragmentManager = getSupportFragmentManager();
                        Bundle bundle = new Bundle();
                        bundle.putString("USERNAME",username);
                        ProfileBusinessFragment fragment = new ProfileBusinessFragment();
                        fragment.setArguments(bundle);

                        // Thực hiện giao tác để thêm Fragment vào Layout
                        fragmentManager.beginTransaction()
                                .replace(R.id.content_frame, fragment)
                                .commit();

                    }



                }
                cursor.close();
            }


            DB.close();





        }
        else if(id==R.id.item_news){
            FragmentManager fragmentManager = getSupportFragmentManager();
            Bundle bundle = new Bundle();
            bundle.putString("USERNAME",username);
            MapsFragment fragment = new MapsFragment();
            fragment.setArguments(bundle);

            // Thực hiện giao tác để thêm Fragment vào Layout
            fragmentManager.beginTransaction()
                    .replace(R.id.content_frame, fragment)
                    .commit();

        }

        else if(id==R.id.item_logout){
            Intent intent= new Intent(getApplicationContext(), OptionsActivity.class);
            startActivity(intent);
        }

        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    public String getUser(){
        return getUserName;
    }

}