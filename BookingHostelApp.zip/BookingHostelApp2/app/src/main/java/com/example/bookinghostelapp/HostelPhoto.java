package com.example.bookinghostelapp;

public class HostelPhoto {
    private int ressourceId;

    public int getRessourceId() {
        return ressourceId;
    }

    public void setRessourceId(int ressourceId) {
        this.ressourceId = ressourceId;
    }

    public HostelPhoto(int ressourceId) {
        this.ressourceId = ressourceId;
    }
}
