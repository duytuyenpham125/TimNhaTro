package com.example.bookinghostelapp.fragment;

import android.database.Cursor;
import android.health.connect.datatypes.HydrationRecord;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.bookinghostelapp.DBHelper;
import com.example.bookinghostelapp.Hostel;
import com.example.bookinghostelapp.HostelAdapter;
import com.example.bookinghostelapp.R;

import java.util.ArrayList;
import java.util.List;


public class HostelViewFragment extends Fragment {
    private RecyclerView rcvHostel;
    private DBHelper dbHelper;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_hostel_view, container, false);

        rcvHostel= view.findViewById(R.id.rcvHostel);
        GridLayoutManager gridLayoutManager=new GridLayoutManager(requireContext(),1);
        rcvHostel.setLayoutManager(gridLayoutManager);


        rcvHostel= view.findViewById(R.id.rcvHostel);

        HostelAdapter hostelAdapter= new HostelAdapter(getListHostel(), new HostelAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                // Handle item click here
                HostelInforForFindFragment hostelInforForFindFragment= new HostelInforForFindFragment();
                Hostel clickedHostel = getListHostel().get(position);
                FragmentTransaction fm= getActivity().getSupportFragmentManager().beginTransaction();

                //Toast.makeText(requireContext(), "Clicked on: " + clickedHostel.getName(), Toast.LENGTH_SHORT).show();

                Bundle bundle = new Bundle();
                bundle.putString("Name",clickedHostel.getName());
                bundle.putString("Address",clickedHostel.getAddress());
                bundle.putString("Price",clickedHostel.getPrice());
                hostelInforForFindFragment.setArguments(bundle);
                fm.replace(R.id.content_frame,hostelInforForFindFragment).addToBackStack(null).commit();

            }

        });
        rcvHostel.setAdapter(hostelAdapter);


        return view;
    }

    String hostelName="",hostelAddress="",hostelPrice="";
    private List<Hostel> getListHostel() {
        List<Hostel> list= new ArrayList<>();
        dbHelper = new DBHelper(getActivity());
        Cursor cursor = dbHelper.getListHost();
        if (cursor != null && cursor.moveToFirst()) {
            do {
                hostelName = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.DB_HOST_HOSTEL_NAME));
                hostelAddress = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.DB_HOST_HOSTEL_ADDRESS));
                hostelPrice = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.DB_HOST_PRICE));
                list.add(new Hostel(hostelName,"Địa Chỉ: "+hostelAddress,"Giá Phòng: "+hostelPrice, R.drawable.baseline_image_24));
            } while (cursor.moveToNext());
        }
        cursor.close();
        dbHelper.close();

        return list;
    }

}