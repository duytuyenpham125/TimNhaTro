package com.example.bookinghostelapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.math.BigInteger;
import java.net.PortUnreachableException;
import java.nio.file.LinkOption;

public class DBHelper extends SQLiteOpenHelper {
    //TABLE
    public static final String DB_ACCOUNT="ACCOUNT";
    public static final String DB_INFORMATION="INFORMATION";

    public static final String DB_HOST="HOST";

    //COLUMMS
    public static final String DB_ACCOUNT_ID_USERS="ID_USERS";
    public static final String DB_ACCOUNT_USERNAME="USERNAME";
    public static final String DB_ACCOUNT_PASSWORD="PASSWORD";


    public static final String DB_INFORMATION_FULL_NAME="FULL_NAME";
    public static final String DB_INFORMATION_ADDRESS="ADDRESS";
    public static final String DB_INFORMATION_CITY="CITY";
    public static final String DB_INFORMATION_EMAIL="EMAIL";
    public static final String DB_INFORMATION_PHONE="PHONE";
    public static final String DB_INFORMATION_BIRTHDAY="BIRTH";
    public static final String DB_INFORMATION_GENDER="GENDER";
    public static final String DB_INFORMATION_USERNAME="USERNAME";
    public static final String DB_ACCOUNT_TYPE="TYPE";


    public static final String DB_HOST_USERNAME="USERNAME";
    public static final String DB_HOST_HOSTEL_NAME="HOSTEL_NAME";
    public static final String DB_HOST_HOSTEL_ADDRESS="HOSTEL_ADDRESS";
    public static final String DB_HOST_ROOM_AMOUNT="ROOM_AMOUNT";
    public static final String DB_HOST_PRICE="PRICE";
    public static final String DB_HOST_STATUS="STATUS";
    public static final String DB_HOST_DESCRIPTION="DESCRIPTION";
    public static final String DB_HOST_LATITUDE="LATITUDE";
    public static final String DB_HOST_LONGITUDE="LONGITUDE";


    private static final String CREATE_TABLE_ACCOUNT =
            "CREATE TABLE " + DB_ACCOUNT + " (" +
                    DB_ACCOUNT_ID_USERS + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    DB_ACCOUNT_USERNAME+ " TEXT NOT NULL," + DB_ACCOUNT_PASSWORD+ " TEXT NOT NULL);";
    public DBHelper(@Nullable Context context) {

        super(context, "Hostel", null , 1);
    }


    @Override
    public void onCreate(SQLiteDatabase MyDB) {



        String CREATE_INFORMATION =
                "CREATE TABLE " + DB_INFORMATION + " (" +
                        DB_INFORMATION_USERNAME + " TEXT PRIMARY KEY, " +
                        DB_INFORMATION_FULL_NAME + " TEXT NOT NULL, " +
                        DB_INFORMATION_BIRTHDAY+ " TEXT NOT NULL,  " +
                        DB_INFORMATION_ADDRESS + " TEXT NOT NULL, " +
                        DB_INFORMATION_CITY + " TEXT NOT NULL, " +
                        DB_INFORMATION_EMAIL + " TEXT NOT NULL, " +
                        DB_INFORMATION_PHONE + " TEXT NOT NULL,"+
                        DB_INFORMATION_GENDER+" TEXT NOT NULL,"+
                        DB_ACCOUNT_TYPE+" TEXT NOT NULL)";

        String CREATE_HOST=
                "CREATE TABLE " +DB_HOST+ "(" +
                        DB_HOST_USERNAME + " TEXT PRIMARY KEY, "+
                        DB_HOST_HOSTEL_NAME + " TEXT NOT NULL, "+
                        DB_HOST_HOSTEL_ADDRESS +" TEXT NOT NULL, "+
                        DB_HOST_ROOM_AMOUNT + " TEXT NOT NULL, "+
                        DB_HOST_PRICE + " TEXT NOT NULL, "+
                        DB_HOST_STATUS + " TEXT NOT NULL, "+
                        DB_HOST_DESCRIPTION + " TEXT NOT NULL,"+
                        DB_HOST_LATITUDE+ " TEXT,"+
                        DB_HOST_LONGITUDE+ " TEXT )";

        MyDB.execSQL(CREATE_HOST);
        MyDB.execSQL(CREATE_TABLE_ACCOUNT);
        MyDB.execSQL(CREATE_INFORMATION);
    }


    //update data
    public void updateInformation(String username, String newFullName, String newBirthday, String newAddress, String newCity, String newEmail, String newPhone, String newGender) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(DBHelper.DB_INFORMATION_FULL_NAME, newFullName);
        values.put(DBHelper.DB_INFORMATION_BIRTHDAY, newBirthday);
        values.put(DBHelper.DB_INFORMATION_ADDRESS, newAddress);
        values.put(DBHelper.DB_INFORMATION_CITY, newCity);
        values.put(DBHelper.DB_INFORMATION_EMAIL, newEmail);
        values.put(DBHelper.DB_INFORMATION_PHONE, newPhone);
        values.put(DBHelper.DB_INFORMATION_GENDER, newGender);

        String whereClause = DBHelper.DB_INFORMATION_USERNAME + "=?";
        String[] whereArgs = {username};

        db.update(DBHelper.DB_INFORMATION, values, whereClause, whereArgs);

        db.close();
    }
    public void updateHost(String username,String hostelName, String hostelAddress, String roomAmount, String price, String status, String description) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues contentValues= new ContentValues();
        contentValues.put("HOSTEL_NAME",hostelName);
        contentValues.put("HOSTEL_ADDRESS",hostelAddress);
        contentValues.put("ROOM_AMOUNT",roomAmount);
        contentValues.put("PRICE",price);
        contentValues.put("STATUS",status);
        contentValues.put("DESCRIPTION",description);
        String whereClause = DBHelper.DB_HOST_USERNAME + "=?";
        String[] whereArgs = {username};

        db.update(DBHelper.DB_HOST,contentValues, whereClause, whereArgs);

        db.close();
    }

    public void updateHostLocation(String username,String latitude,String longitude) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues contentValues= new ContentValues();
        contentValues.put("LATITUDE",latitude);
        contentValues.put("LONGITUDE", longitude);
        String whereClause = DBHelper.DB_HOST_USERNAME + "=?";
        String[] whereArgs = {username};

        db.update(DBHelper.DB_HOST,contentValues, whereClause, whereArgs);

        db.close();
    }

    //insert data

    public  Boolean insertHost(String username,String hostel_name,String hostel_address,String room_amount,String price,String status,String description)
    {
        SQLiteDatabase MyDB=this.getWritableDatabase();

        ContentValues contentValues= new ContentValues();
        contentValues.put("USERNAME",username);
        contentValues.put("HOSTEL_NAME",hostel_name);
        contentValues.put("HOSTEL_ADDRESS",hostel_address);
        contentValues.put("ROOM_AMOUNT",room_amount);
        contentValues.put("PRICE",price);
        contentValues.put("STATUS",status);
        contentValues.put("DESCRIPTION",description);
        contentValues.put("LATITUDE","");
        contentValues.put("LONGITUDE","");
        long result = MyDB.insert("HOST",null,contentValues);
        if(result==-1){
            return false;
        }
        else return true;
    }

    public  Boolean insertData(String username,String password){
        SQLiteDatabase MyDB= this.getWritableDatabase();

        ContentValues contentValues=    new ContentValues();
        contentValues.put("username",username);
        contentValues.put("password",password);
        long result = MyDB.insert("ACCOUNT",null,contentValues);
        if(result==-1)
        {
            return  false;
        }
        else return true;

    }

    public  Boolean insertInformation(String username,String fullName,String birthday,String address,String city,String email,String phone,String gender,String type){
        SQLiteDatabase MyDB= this.getWritableDatabase();

        ContentValues contentValues=new ContentValues();
        contentValues.put("USERNAME",username);
        contentValues.put("FULL_NAME",fullName);
        contentValues.put("BIRTH",birthday);
        contentValues.put("ADDRESS",address);
        contentValues.put("CITY",city);
        contentValues.put("EMAIL",email);
        contentValues.put("PHONE",phone);
        contentValues.put("GENDER",gender);
        contentValues.put("TYPE",type);
        long result = MyDB.insert("INFORMATION",null,contentValues);
        if (result==-1){

            return false;

        }
        else  return true;


    }

    //check data
    public  Boolean checkusernameHost(String username){
        SQLiteDatabase MyDB= this.getWritableDatabase();
        Cursor cursor=MyDB.rawQuery("Select * from HOST where username=?",new String[]{username});
        if(cursor.getCount()>0) return true;
        else return  false;
    }
    public  Boolean checkusernameInfor(String username){
        SQLiteDatabase MyDB= this.getWritableDatabase();
        Cursor cursor=MyDB.rawQuery("Select * from INFORMATION where username=?",new String[]{username});
        if(cursor.getCount()>0) return true;
        else return  false;
    }
    public  Boolean checkusername(String username){
        SQLiteDatabase MyDB= this.getWritableDatabase();
        Cursor cursor=MyDB.rawQuery("Select * from ACCOUNT where username=?",new String[]{username});
        if(cursor.getCount()>0) return true;
        else return  false;
    }
    public  Boolean checkaccount(String username,String password){
        SQLiteDatabase MyDB= this.getWritableDatabase();
        Cursor cursor=MyDB.rawQuery("Select * from ACCOUNT where username=? and password=?",new String[]{username,password});
        if(cursor.getCount()>0) return true;
        else return  false;
    }
    public  Boolean checkuserHost(String hosterName){
        SQLiteDatabase MyDB= this.getWritableDatabase();
        Cursor cursor=MyDB.rawQuery("Select USERNAME from HOST where HOSTEL_NAME=?",new String[]{hosterName});
        if(cursor.getCount()>0) return true;
        else return  false;
    }

    public Cursor getAccount() {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + DB_ACCOUNT;
        return db.rawQuery(query, null);
    }
    public Cursor getListHost() {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT HOSTEL_NAME,HOSTEL_ADDRESS,PRICE FROM " + DB_HOST;
        return db.rawQuery(query, null);
    }
    public Cursor getInformationByUsername(String username) {
        SQLiteDatabase db = this.getReadableDatabase();

        String[] projection = {
                DB_INFORMATION_USERNAME,
                DB_INFORMATION_FULL_NAME,
                DB_INFORMATION_BIRTHDAY,
                DB_INFORMATION_ADDRESS,
                DB_INFORMATION_CITY,
                DB_INFORMATION_GENDER,
                DB_INFORMATION_PHONE,
                DB_INFORMATION_EMAIL,
                DB_ACCOUNT_TYPE

        };

        // Câu lệnh WHERE để chỉ lấy dữ liệu của username cụ thể
        String selection = DB_INFORMATION_USERNAME + "=?";
        String[] selectionArgs = {username};

        // Thực hiện truy vấn
        return db.query(DB_INFORMATION, projection, selection, selectionArgs, null, null, null);
    }
    public Cursor getHostByUsername(String username) {
        SQLiteDatabase db = this.getReadableDatabase();

        String[] projection = {
                DB_HOST_HOSTEL_NAME,
                DB_HOST_HOSTEL_ADDRESS,
                DB_HOST_ROOM_AMOUNT,
                DB_HOST_STATUS,
                DB_HOST_PRICE,
                DB_HOST_DESCRIPTION,
                DB_HOST_LATITUDE,
                DB_HOST_LONGITUDE

        };

        // Câu lệnh WHERE để chỉ lấy dữ liệu của username cụ thể
        String selection = DB_HOST_USERNAME + "=?";
        String[] selectionArgs = {username};

        // Thực hiện truy vấn
        return db.query(DB_HOST, projection, selection, selectionArgs, null, null, null);
    }
    public Cursor getHostLocationByUsername(String hostelName) {
        SQLiteDatabase db = this.getReadableDatabase();

        String[] projection = {
                DB_HOST_LATITUDE,
                DB_HOST_LONGITUDE

        };

        // Câu lệnh WHERE để chỉ lấy dữ liệu của username cụ thể
        String selection = DB_HOST_HOSTEL_NAME + "=?";
        String[] selectionArgs = {hostelName};

        // Thực hiện truy vấn
        return db.query(DB_HOST, projection, selection, selectionArgs, null, null, null);
    }
    public Cursor getUsernameByHostelName(String hostelName) {
        SQLiteDatabase db = this.getReadableDatabase();

        String[] projection = {DB_HOST_USERNAME};

        // WHERE clause to filter results based on hostelName
        String selection = DB_HOST_HOSTEL_NAME + "=?";
        String[] selectionArgs = {hostelName};

        // Execute the query
        return db.query(DB_HOST, projection, selection, selectionArgs, null, null, null);
    }
    public Cursor getHost() {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + DB_INFORMATION;
        return db.rawQuery(query, null);
    }
    //action
    public  SQLiteDatabase open(){
        return this.getWritableDatabase();
    }
    @Override
    public void onUpgrade(SQLiteDatabase MyDB, int i, int i1) {

        MyDB.execSQL("DROP TABLE IF EXISTS " + DB_ACCOUNT);
        MyDB.execSQL("DROP TABLE IF EXISTS " + DB_HOST);
        MyDB.execSQL("DROP TABLE IF EXISTS " + DB_INFORMATION);
        onCreate(MyDB);
    }
}
