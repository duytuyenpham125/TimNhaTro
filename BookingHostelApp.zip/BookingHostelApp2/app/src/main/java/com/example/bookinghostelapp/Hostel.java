package com.example.bookinghostelapp;

import android.widget.ImageView;

public class Hostel {
    private String name;
    private String address;
    private String price;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Hostel(String username) {
        this.username = username;
    }

    private String username;
    private int img;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img = img;
    }

    public Hostel(String name, String address, String price, int img) {
        this.name = name;
        this.address = address;
        this.price = price;
        this.img = img;
    }
}
