package com.example.bookinghostelapp.fragment;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager.widget.ViewPager;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.bookinghostelapp.DBHelper;
import com.example.bookinghostelapp.Hostel;
import com.example.bookinghostelapp.HostelPhoto;
import com.example.bookinghostelapp.HostelPhotoAdapter;
import com.example.bookinghostelapp.R;

import org.w3c.dom.Text;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import me.relex.circleindicator.CircleIndicator;

public class HostelInforForFindFragment extends Fragment {

    TextView txtName,txtAddress,txtPrice,txtPhone;
    ImageButton btPhoneCall,btLocation;
    static int PERMISSION_CODE=100;
    private ViewPager viewPager;
    private CircleIndicator circleIndicator;
    private HostelPhotoAdapter hostelPhotoAdapter;
    private DBHelper dbHelper;
    String phoneNumb="";
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_hostel_infor_for_find, container, false);

        dbHelper=new DBHelper(requireContext());


        if(ContextCompat.checkSelfPermission(requireContext(), android.Manifest.permission.CALL_PHONE)!= PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(requireActivity(),new String[]{Manifest.permission.CALL_PHONE},PERMISSION_CODE);
        }


        viewPager=view.findViewById(R.id.viewpager);
        circleIndicator=view.findViewById(R.id.circle_indicator);

        hostelPhotoAdapter= new HostelPhotoAdapter(this,getListPhoto());
        viewPager.setAdapter(hostelPhotoAdapter);

        circleIndicator.setViewPager(viewPager);
        hostelPhotoAdapter.registerDataSetObserver(circleIndicator.getDataSetObserver());
        Bundle bundle = getArguments();

        assert bundle != null;
        String dataName = bundle.getString("Name");
            String dataAddress = bundle.getString("Address");
            String dataPrice = bundle.getString("Price");
            txtName=view.findViewById(R.id.hostelnamecontact);
            txtAddress=view.findViewById(R.id.txtHostelAddress);
            txtPrice=view.findViewById(R.id.txtPrice);
            txtPhone=view.findViewById(R.id.txtPhoneContact);
            txtName.setText("Tên Trọ: "+dataName);
            txtAddress.setText(dataAddress);
            txtPrice.setText(dataPrice);
        Log.d("YourFragment", "dataName: " + dataName);

            dbHelper.open();

            String hostelNameToSearch = dataName; // Đặt giá trị cụ thể ở đây




            Cursor cursor = dbHelper.getUsernameByHostelName(hostelNameToSearch);
            Cursor cursor2=dbHelper.getHostLocationByUsername(hostelNameToSearch);


            if (cursor.moveToFirst()) {
                do {
                    String username1 = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.DB_HOST_USERNAME));
                    Cursor cursor1=dbHelper.getInformationByUsername(username1);
                    if(cursor1.moveToFirst()){
                        do{
                            String text=cursor1.getString(cursor1.getColumnIndexOrThrow(DBHelper.DB_INFORMATION_PHONE));
                            txtPhone.setText("Liên Hệ: "+text);
                            phoneNumb=text;

                        }while(cursor1.moveToNext());
                    }

                } while (cursor.moveToNext());
            } else {
                //Toast.makeText(requireContext(), "Không tìm thấy bản ghi cho " + hostelNameToSearch, Toast.LENGTH_SHORT).show();
            }
            cursor.close();
        btPhoneCall=view.findViewById(R.id.imgbuttoncontact);
        btPhoneCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phoneNumber = "tel:" + phoneNumb ; // Thay thế bằng số điện thoại thực tế

                Intent dialIntent = new Intent(Intent.ACTION_CALL, Uri.parse(phoneNumber));

                if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
                    startActivity(dialIntent);
                } else {
                    requestCallPermission();
                }

            }
        });
        btLocation=view.findViewById(R.id.imgbuttonLocation);
        btLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MapsFragmentHostView maps= new MapsFragmentHostView();
                FragmentTransaction fm= getActivity().getSupportFragmentManager().beginTransaction();
                if(cursor2.moveToFirst()){
                    String latitude= cursor2.getString(cursor2.getColumnIndexOrThrow(DBHelper.DB_HOST_LATITUDE));
                    String longitude= cursor2.getString(cursor2.getColumnIndexOrThrow(DBHelper.DB_HOST_LONGITUDE));



                Bundle bundle = new Bundle();
                bundle.putString("LATITUDE",latitude);
                bundle.putString("LONGITUDE",longitude);
                bundle.putString("NAME",hostelNameToSearch);
                maps.setArguments(bundle);
                fm.replace(R.id.content_frame,maps).commit();

                Toast.makeText(requireContext(), " Location onclick ", Toast.LENGTH_SHORT).show();
            }
            }
        });





        return view;
    }
    private List<HostelPhoto> getListPhoto(){
        List<HostelPhoto> list=new ArrayList<>();
        list.add(new HostelPhoto(R.drawable.mainviewbackground));
        list.add(new HostelPhoto(R.drawable.mainviewbackground));
        list.add(new HostelPhoto(R.drawable.mainviewbackground));
        list.add(new HostelPhoto(R.drawable.mainviewbackground));
        return list;
    }
    private void makePhoneCall() {


    }

    private void requestCallPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(new String[]{Manifest.permission.CALL_PHONE}, PERMISSION_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                makePhoneCall();
            } else {
                Toast.makeText(requireContext(), "Permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}