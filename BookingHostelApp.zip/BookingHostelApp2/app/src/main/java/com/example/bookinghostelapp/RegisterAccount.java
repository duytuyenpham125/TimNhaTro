package com.example.bookinghostelapp;

import static java.io.Console.*;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.Console;

public class RegisterAccount extends AppCompatActivity {
    EditText usernameRe,passwordRe,repasswordRe;
    Button registerRe;
    DBHelper DB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_account);
        DB=new DBHelper(this);

            usernameRe=(EditText) findViewById(R.id.txt_RegUsername);
            passwordRe=(EditText) findViewById(R.id.txt_RegPassword);
            repasswordRe=(EditText) findViewById(R.id.confirmtxt_RegPassword);
            registerRe=(Button) findViewById(R.id.bttRegister);
            registerRe.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    DB.open();
                    String user=usernameRe.getText().toString();
                    String password=passwordRe.getText().toString();
                    String Repass=repasswordRe.getText().toString();
                    if(user.equals("")||password.equals("")||Repass.equals("")){
                        Toast.makeText(RegisterAccount.this,"Thong tin bi trong",Toast.LENGTH_SHORT).show();
                    }
                    else {
                        if(password.length()>=8){
                            if(password.equals(Repass)){
                                Boolean checkuser=DB.checkusername(user);
                                if(checkuser==false){
                                    Boolean insert= DB.insertData(user,password);
                                    if(insert==true){
                                        Toast.makeText(RegisterAccount.this,"Dang Ki thanh cong",Toast.LENGTH_SHORT).show();
                                        Intent intent= new Intent(getApplicationContext(), MainViewLayout.class);
                                        intent.putExtra("USERNAME", user);
                                        Intent intentFill= new Intent(getApplicationContext(), FillInformationForFindHostel.class);
                                        intentFill.putExtra("USERNAME", user);
                                        startActivity(intent);

                                    }
                                    else{
                                        Toast.makeText(RegisterAccount.this,"Dang Ki khong thanh cong",Toast.LENGTH_SHORT).show();
                                    }
                                }
                                else{
                                    Toast.makeText(RegisterAccount.this,"Tai khoan da ton tai",Toast.LENGTH_SHORT).show();
                                }

                            }
                            else{
                                Toast.makeText(RegisterAccount.this,"Mat Khau khong trung khop",Toast.LENGTH_SHORT).show();
                            }
                        }
                        else {
                            Toast.makeText(RegisterAccount.this,"Mat Khau Toi Thieu 8 ki tu",Toast.LENGTH_SHORT).show();
                        }

                    }

                }
            });

    }
}