package com.example.bookinghostelapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.Toast;


public class OptionsActivity extends AppCompatActivity {
    Button bttLogin,bttRegister;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

                setContentView(R.layout.activity_options);
                bttRegister=findViewById(R.id.bttOptionRegister);
                bttLogin=findViewById(R.id.bttOptionLogin);
                bttLogin.setOnClickListener(view ->{
                    Intent intent= new Intent(getApplicationContext(), LoginActivity.class);
                    startActivity(intent);
                });

                bttRegister.setOnClickListener(view -> {
                    Intent intent= new Intent(getApplicationContext(), RegisterAccount.class);
                    startActivity(intent);
                });
    }

}
