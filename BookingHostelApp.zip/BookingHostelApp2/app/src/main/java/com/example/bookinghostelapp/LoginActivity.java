package com.example.bookinghostelapp;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    EditText username,password;
    Button Login;
    DBHelper DB;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        username= findViewById(R.id.txtLoginUsername);
        password=findViewById(R.id.txtLoginPassword);
        Login=findViewById(R.id.bttLogin);
        DB=new DBHelper(this);
        Login.setOnClickListener(view -> {

               String user= username.getText().toString();
                String pass=password.getText().toString();
                if(user.equals("")||pass.equals("")){

                        Toast.makeText(LoginActivity.this,"Thong tin bi trong",Toast.LENGTH_SHORT).show();

                }
                else {
                    Boolean checkuser=DB.checkaccount(user,pass);
                    if(checkuser){
                        Toast.makeText(LoginActivity.this,"Dang Nhap Thanh Cong",Toast.LENGTH_SHORT).show();
                        Intent intent= new Intent(getApplicationContext(), MainViewLayout.class);
                        intent.putExtra("USERNAME", user);
                        Intent intentFill= new Intent(getApplicationContext(), FillInformationForFindHostel.class);
                        intentFill.putExtra("USERNAME", user);
                        startActivity(intent);


                    }
                    else {
                        Toast.makeText(LoginActivity.this,"Dang Nhap Khong Thanh Cong",Toast.LENGTH_SHORT).show();
                    }
                }
        });


    }
}