package com.example.bookinghostelapp.fragment;

import static android.content.Intent.getIntent;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import com.example.bookinghostelapp.DBHelper;
import com.example.bookinghostelapp.FillInformationForFindHostel;
import com.example.bookinghostelapp.MainViewLayout;
import com.example.bookinghostelapp.R;
import com.example.bookinghostelapp.SubmitHost;

import java.util.Objects;


public class ProfileFragment extends Fragment {
    private EditText usernameEditText;
    private EditText fullNameEditText, birthdayEditText, addressEditText, cityEditText, emailEditText, phoneEditText;
    // Thêm các EditText tương ứng với các cột khác
    private RadioButton rdbNam, rdbNu;
    private DBHelper dbHelper;
    Button btUpdate;

    private MainViewLayout mMainView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_profile, container, false);
        fullNameEditText = view.findViewById(R.id.editTextFullName);
        birthdayEditText = view.findViewById(R.id.editTextDOB);
        addressEditText = view.findViewById(R.id.editTextAddress);
        cityEditText = view.findViewById(R.id.editTextAddressProvince);
        emailEditText = view.findViewById(R.id.editTextEmail);
        phoneEditText = view.findViewById(R.id.editTextPhoneNumber);
        rdbNam = view.findViewById(R.id.radioButtonMale);
        rdbNu = view.findViewById(R.id.radioButtonFemale);
        btUpdate = view.findViewById(R.id.buttonUpdate);
        // Ánh xạ các EditText khác tương ứng

        mMainView=(MainViewLayout) getActivity();

        dbHelper = new DBHelper(getActivity());
        String username=mMainView.getUser();

        Cursor cursor = dbHelper.getInformationByUsername(username);

        if (cursor.moveToFirst()) {
            // Lấy giá trị từ Cursor và đặt vào từng EditText
            fullNameEditText.setText(cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.DB_INFORMATION_FULL_NAME)));
            birthdayEditText.setText(cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.DB_INFORMATION_BIRTHDAY)));
            addressEditText.setText(cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.DB_INFORMATION_ADDRESS)));
            cityEditText.setText(cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.DB_INFORMATION_CITY)));
            emailEditText.setText(cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.DB_INFORMATION_EMAIL)));
            phoneEditText.setText(cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.DB_INFORMATION_PHONE)));
            String gender = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.DB_INFORMATION_GENDER));
            if (Objects.equals(gender, "Nam")) {
                rdbNam.setChecked(true);
            } else if (Objects.equals(gender, "Nữ")) {
                rdbNu.setChecked(true);
            }
            // Đặt giá trị vào các EditText khác tương ứng
        }
        cursor.close();
        // Đóng Cursor sau khi sử dụng

            btUpdate.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dbHelper.open();
                    String fullName=fullNameEditText.getText().toString();
                    String birthday=birthdayEditText.getText().toString();
                    String address=addressEditText.getText().toString();
                    String city=cityEditText.getText().toString();
                    String phone=phoneEditText.getText().toString();
                    String email=emailEditText.getText().toString();

                    String gender = "";
                    if(rdbNam.isChecked()==true)
                        gender="Nam";
                    else if(rdbNu.isChecked()==true)
                        gender="Nữ";
                    dbHelper.updateInformation(username,fullName,birthday,address,city,phone,email,gender);
                    Toast.makeText(requireContext(),"Đã thay đổi thông tin! Xin hãy tải lại trang !!!", Toast.LENGTH_SHORT).show();
                    dbHelper.close();
                }
            });

        // Gọi phương thức để lấy dữ liệu từ bảng
        return view;

    }


}